//Clase Juego
#pragma once
#include <ncurses.h>
#include <cstdlib>
#include <string>
#include "Constantes.h"  
#include "Interfaz.h" 
#include "Jugador.h" 
#include "Mapa.h"

class Juego {
///////////////////////////////////////////////////////////////////////////
private:
    bool salirJuego;
    Jugador jugador;
    Mapa mapa;
    bool gameOver;
    int puntaje;
/////////////////////////////////////////////////////////////////////////// 
public:
    Juego();
    bool menu_principal();
    void reiniciarJuego();
};


