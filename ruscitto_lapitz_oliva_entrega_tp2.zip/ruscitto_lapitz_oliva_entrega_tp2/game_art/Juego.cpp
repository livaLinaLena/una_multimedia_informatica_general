#include "Juego.h"
#include <ncurses.h>
#include <cstdlib>
#include <string>
#include <cctype>
#include "Interfaz.h"
#include "Jugador.h"
#include "Mapa.h"
//////////////////////////////////////////////////////////////////////////////////////////////
Juego::Juego() : salirJuego(false), gameOver(false), puntaje(0) {}
//////////////////////////////////////////////////////////////////////////////////////////////
// Función para mostrar el menú principal y manejar las opciones
bool Juego::menu_principal() {
    char opcion;
    bool jugar = false;
    do {
        Interfaz::mostrar_titulo();
        opcion = getch();
        char opcion_min =  Interfaz::a_minuscula(opcion);
        
        switch (opcion_min) {
            case 'j':
                jugar = true;
                break;
            case 'i':
                 Interfaz::mostrar_instrucciones();
                break;
            case 'q':
                salirJuego = true;
                break;
            default:
                // Si presiona otra tecla, seguir mostrando el menú
                break;
        }
        } while (!jugar && !salirJuego);

    
    return jugar;
}
//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
void Juego::reiniciarJuego() {
    gameOver = false;
    jugador.reiniciar();
    puntaje = 0;
    
    for (int i = 0; i < ALTO; i++) {
        for (int j = 0; j < ANCHO; j++) {
            if (mapa.getCelda(i, j) == CAMINADO) {
                mapa.setCelda(i, j, PASTO);
            }  
        }
    }
    clear();
}


