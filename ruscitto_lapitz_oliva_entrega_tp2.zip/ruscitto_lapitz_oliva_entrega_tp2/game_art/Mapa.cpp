#include "Mapa.h"
#include <cstdlib>
#include <ctime>
#include <ncurses.h>
//////////////////////////////////////////////////////////////////////////////////////////////
Mapa::Mapa() {};
//////////////////////////////////////////////////////////////////////////////////////////////
void Mapa::inicializar() {
    // Inicializar todo el mapa con pasto
    for (int i = 0; i < ALTO; i++) {
        for (int j = 0; j < ANCHO; j++) {
            celdas[i][j] = PASTO;
        }
    }

    // Agregar montañas
    celdas[4][20] = MONTANIA;
    celdas[5][19] = MONTANIA; 
    celdas[5][20] = MONTANIA;
    celdas[6][18] = MONTANIA; 
    celdas[6][19] = MONTANIA; 
    celdas[6][20] = MONTANIA; 
    celdas[6][21] = MONTANIA;
    celdas[7][16] = MONTANIA; 
    celdas[7][17] = MONTANIA; 
    celdas[7][18] = MONTANIA; 
    celdas[7][19] = MONTANIA; 
    celdas[7][20] = MONTANIA; 
    celdas[7][21] = MONTANIA; 
    celdas[7][22] = MONTANIA;

     // Agregar agua
    for (int i = 20; i < 30; i++) celdas[10][i] = AGUA;
    for (int i = 15; i < 35; i++) celdas[11][i] = AGUA;
    for (int i = 15; i < 25; i++) celdas[12][i] = AGUA;
    for (int i = 15; i < 20; i++) celdas[13][i] = AGUA;
    
    // Agregar edificios
    for (int i = 35; i < 44; i++) {
        celdas[35][i] = EDIFICIO;
        celdas[36][i] = EDIFICIO;
        celdas[37][i] = EDIFICIO;
        celdas[38][i] = EDIFICIO;
        celdas[39][i] = EDIFICIO;
    }
}
//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
void Mapa::dibujar_mapa() {
    for (int y = 1; y < ALTO - 1; y++) {
        for (int x = 1; x < ANCHO - 1; x++) {
            char terreno = celdas[y][x];
            switch (terreno) {
                case PASTO:
                    attron(COLOR_PAIR(PAR_PASTO));
                    mvaddch(y, x, PASTO);
                    attroff(COLOR_PAIR(PAR_PASTO));
                    break;
                case CAMINADO:
                    attron(COLOR_PAIR(PAR_CAMINADO));
                    mvaddch(y, x, CAMINADO);
                    attroff(COLOR_PAIR(PAR_CAMINADO));
                    break;
                case AGUA:
                    attron(COLOR_PAIR(PAR_AGUA));
                    mvaddch(y, x, AGUA);
                    attroff(COLOR_PAIR(PAR_AGUA));
                    break;
                case MONTANIA:
                    attron(COLOR_PAIR(PAR_MONTANIA));
                    mvaddch(y, x, MONTANIA);
                    attroff(COLOR_PAIR(PAR_MONTANIA));
                    break;
                case EDIFICIO:
                    attron(COLOR_PAIR(PAR_EDIFICIO));
                    mvaddch(y, x, EDIFICIO);
                    attroff(COLOR_PAIR(PAR_EDIFICIO));
                    break;
                case PREMIO:
                    attron(COLOR_PAIR(PAR_PREMIO));
                    mvaddch(y, x, PREMIO);
                    attroff(COLOR_PAIR(PAR_PREMIO));
                    break;
            }
        }
    }
}
//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
    char Mapa::getCelda(int y, int x) const {
    if(y >= 0 && y < ALTO && x >= 0 && x < ANCHO) {
        return celdas[y][x]; 
    }
    return ' ';
}
//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
    void Mapa::setCelda(int y, int x, char valor) {
    if (y >= 0 && y < ALTO && x >= 0 && x < ANCHO) {
        celdas[y][x] = valor;
    }
    }
//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
    void Mapa::colocarPremio(int &py, int &px) {
    int y, x;
    do {
        y = rand() % ALTO;
        x = rand() % ANCHO;
    } while (celdas[y][x] != PASTO);
    celdas[y][x] = PREMIO;
    py = y;
    px = x;
}
//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
    void Mapa::dibujar_paso(int y, int x) {
    setCelda(y, x, CAMINADO);
    attron(COLOR_PAIR(PAR_CAMINADO));
    mvaddch(y, x, CAMINADO);
    attroff(COLOR_PAIR(PAR_CAMINADO));
}
//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
    bool Mapa::puede_moverse(int y, int x) const {
    if (y <= 0 || y >= ALTO - 1 || x <= 0 || x >= ANCHO - 1)
        return false;
    char terreno = getCelda(y, x);
    return (terreno == PASTO || terreno == CAMINADO || terreno == PREMIO);
    }

