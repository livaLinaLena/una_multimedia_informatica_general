//Clase Interfaz
#pragma once
#include "Constantes.h"
#include <ncurses.h>
#include <string>
#include <cstdlib>
#include <ctime>    
//////////////////////////////////////////////////////////////////////////////
class Interfaz {
    public:
    static void inicializar_colores();
    static void mostrar_titulo();
    static void mostrar_instrucciones();
    static void mostrar_introduccion();
    static void mostrar_puntaje(int puntaje);
    static void mostrar_game_over(int puntaje);
    static char a_minuscula(char c);
};

