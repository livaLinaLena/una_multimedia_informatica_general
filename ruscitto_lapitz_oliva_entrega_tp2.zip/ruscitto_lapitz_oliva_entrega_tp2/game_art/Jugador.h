// Clase Jugador 
#pragma once
#include "Constantes.h" 

class Jugador {
///////////////////////////////////////////////////////////////////////////
private:
    int x, y;
    int puntaje;
///////////////////////////////////////////////////////////////////////////
public:
    Jugador();
    void mover(int nuevaX, int nuevaY);
    int getX() const;
    int getY() const;
    void sumarPuntaje(int puntos);
    int getPuntaje() const;
    void reiniciar();
};


