#include <string>
#include <cstdlib>
#include <ctime>
#include "Interfaz.h"
#include "Mapa.h"
#include "Jugador.h"
using namespace std;

//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
void Interfaz::inicializar_colores(){
    start_color();
    init_pair(PAR_PASTO, COLOR_YELLOW, COLOR_GREEN);
    init_pair(PAR_CAMINADO, COLOR_YELLOW, COLOR_BLACK);
    init_pair(PAR_AGUA, COLOR_CYAN, COLOR_BLUE);
    init_pair(PAR_MONTANIA, COLOR_BLACK, COLOR_WHITE);
    init_pair(PAR_JUGADOR, COLOR_RED, COLOR_BLACK);
    init_pair(PAR_EDIFICIO, COLOR_BLACK, COLOR_RED);
    init_pair(PAR_PREMIO, COLOR_MAGENTA, COLOR_RED);
}
//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
void Interfaz::mostrar_titulo() {
    clear();

    // Cartel
    const char *cartel_titulo[] = {
         "/$$$$$$$                                 /$$              ",
        "| $$__  $$                               | $$              ",
        "| $$  \\ $$ /$$$$$$   /$$$$$$   /$$$$$$  /$$$$$$    /$$$$$$ ",
        "| $$$$$$$/|____  $$ /$$__  $$ /$$__  $$|_  $$_/   |____  $$",
        "| $$____/  /$$$$$$$| $$  \\ $$| $$  \\ $$  | $$      /$$$$$$$",
        "| $$      /$$__  $$| $$  | $$| $$  | $$  | $$ /$$ /$$__  $$",
        "| $$     |  $$$$$$$| $$$$$$$/|  $$$$$$/  |  $$$$/|  $$$$$$$",
        "|__/      \\_______/| $$____/  \\______/    \\___/   \\_______/",
        "                   | $$                                    ",
        "                   | $$                                    ",
        "                   |__/                                    ",
        NULL
    };
    ////////////////////////////////
    attron(COLOR_PAIR(PAR_EDIFICIO));
    for (int i = 0; cartel_titulo[i] != NULL; i++) {
        mvprintw((ALTO / 2 - 8) + i, (ANCHO - 60) / 2, "%s", cartel_titulo[i]);
    }
    attroff(COLOR_PAIR(PAR_EDIFICIO));
    ////////////////////////////////

    // Instrucciones en el menu principal
    attron(COLOR_PAIR(PAR_JUGADOR));
    mvprintw(ALTO / 2 + 2, (ANCHO - 50) / 2, "Consigue toda la papota (M) para crecer!");
    mvprintw(ALTO / 2 + 3, (ANCHO - 40) / 2, "No salgas del gimnasio o perderas!");
    attroff(COLOR_PAIR(PAR_JUGADOR));

    // Controles control y exit
    attron(COLOR_PAIR(PAR_PREMIO));
    mvprintw(ALTO / 2 + 5, (ANCHO - 30) / 2, "Controles: Flechas o WASD");
    mvprintw(ALTO / 2 + 6, (ANCHO - 20) / 2, "Q - Salir del juego");
    attroff(COLOR_PAIR(PAR_PREMIO));

    // Opciones del menu
    attron(A_BOLD | COLOR_PAIR(PAR_JUGADOR));
    mvprintw(ALTO / 2 + 9, (ANCHO - 20) / 2, "J - Jugar");
    mvprintw(ALTO / 2 + 10, (ANCHO - 20) / 2, "I - Mas Instrucciones");
    mvprintw(ALTO / 2 + 11, (ANCHO - 20) / 2, "Q - Salir");
    attroff(A_BOLD | COLOR_PAIR(PAR_JUGADOR));

    refresh();
}
//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
void Interfaz::mostrar_instrucciones() {
    clear();

    // Cartel
    const char *titulo_instrucciones[] = {
        "  _____           _                   _             _               _   ",
        " |_   _|         | |                 | |           | |             | |  ",
        "   | |  _ __  ___| |_ _ __ _   _  ___| |_ ___  _ __| |__   ___  ___| |_ ",
        "   | | | '_ \\/ __| __| '__| | | |/ __| __/ _ \\| '__| '_ \\ / _ \\/ __| __|",
        "  _| |_| | | \\__ \\ |_| |  | |_| | (__| || (_) | |  | |_) |  __/\\__ \\ |_ ",
        " |_____|_| |_|___/\\__|_|   \\__,_|\\___|\\__\\___/|_|  |_.__/ \\___||___/\\__|",
        NULL
    };

    attron(COLOR_PAIR(PAR_EDIFICIO));
    for (int i = 0; titulo_instrucciones[i] != NULL; i++) {
        mvprintw(2 + i, (ANCHO - 70) / 2, "%s", titulo_instrucciones[i]);
    }
    attroff(COLOR_PAIR(PAR_EDIFICIO));

    // Texto de instrucciones
    string texto_instrucciones = 
        "Eres RAIMUNDO LOPEZ, un fisicoculturista que necesita tomar mucha papota para crecer.\n\n"
        "Tu mision es conseguir toda la papota dentro del gimnasio lo mas rapido posible\n"
        "y sin salirte del mismo.\n\n"
        "CONTROLES:\n"
        "W, Flecha Arriba    - Moverse hacia arriba\n"
        "S, Flecha Abajo     - Moverse hacia abajo\n"
        "A, Flecha Izquierda - Moverse hacia la izquierda\n"
        "D, Flecha Derecha   - Moverse hacia la derecha\n"
        "Q                   - Salir del juego\n\n"
        "OBJETIVO:\n"
        "Recolecta toda la papota (M) para ganar puntos.\n"
        "Evita salir del gimnasio o chocar contra obstaculos.";

    attron(COLOR_PAIR(PAR_JUGADOR));
    int y = 10;
    int x = 5;
    
    // Dividir el texto en líneas
    size_t inicio = 0;
    size_t fin = texto_instrucciones.find('\n');
    
    while (fin != string::npos) {
        string linea = texto_instrucciones.substr(inicio, fin - inicio);
        mvprintw(y++, x, "%s", linea.c_str());
        inicio = fin + 1;
        fin = texto_instrucciones.find('\n', inicio);
    }
    string ultima_linea = texto_instrucciones.substr(inicio);
    mvprintw(y, x, "%s", ultima_linea.c_str());
    
    mvprintw(y + 2, x, "Presiona cualquier tecla para volver al menu principal...");
    
    attroff(COLOR_PAIR(PAR_JUGADOR));

    refresh();
    getch(); // Esperar a que el usuario presione una tecla
}
//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
void Interfaz::mostrar_introduccion() {
    clear();
    
    string intro = "Papota, el juego. Eres un fisicoculturista que necesita poder crecer mas \n"
                   "y estar mas fuerte y sano, bueno eso de sano vamos viendo.\n\n"
                   "En este mundo de hierro y sudor, solo la papota te dara la fuerza \n"
                   "necesaria para convertirte en el campeon que siempre soñaste ser.\n\n"
                   "Pero cuidado: fuera del gimnasio te espera el fracaso y la debilidad.";
    
    attron(COLOR_PAIR(PAR_JUGADOR));
    int y = ALTO/2 - 5;
    int x = (ANCHO - 70)/2;
    
    size_t inicio = 0;
    size_t fin = intro.find('\n');
    
    while (fin != string::npos) {
        string linea = intro.substr(inicio, fin - inicio);
        mvprintw(y++, x, "%s", linea.c_str());
        inicio = fin + 1;
        fin = intro.find('\n', inicio);
    }
    string ultima_linea = intro.substr(inicio);
    mvprintw(y, x, "%s", ultima_linea.c_str());
    
    mvprintw(y + 2, x, "Presiona cualquier tecla para continuar...");
    
    attroff(COLOR_PAIR(PAR_JUGADOR));
    
    refresh();
    getch();
}
//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
void Interfaz::mostrar_puntaje(int puntaje) {
    for (int y = 1; y <= 2; y++) {
        for (int x = ANCHO - 15; x < ANCHO - 5; x++) {
            attron(COLOR_PAIR(PAR_PASTO));
            mvaddch(y, x, PASTO);
            attroff(COLOR_PAIR(PAR_PASTO));
        }
    }
    attron(COLOR_PAIR(PAR_MONTANIA));
    mvprintw(1, ANCHO - 15, "PUNTAJE: %d", puntaje);
    attroff(COLOR_PAIR(PAR_MONTANIA));
}
//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
void Interfaz::mostrar_game_over(int puntaje) { 
    clear();

    // Cartel 
    const char *cartel_gameover[] = {
        "   _____                         ____                 ",
        "  / ____|                       / __ \\                ",
        " | |  __  __ _ _ __ ___   ___  | |  | |_   _____ _ __ ",
        " | | |_ |/ _` | '_ ` _ \\ / _ \\ | |  | \\ \\ / / _ \\ '__|",
        " | |__| | (_| | | | | | |  __/ | |__| |\\ V /  __/ |   ",
        "  \\_____|\\__,_|_| |_| |_|\\___|  \\____/  \\_/ \\___|_|   ",
        NULL
    };

    attron(COLOR_PAIR(PAR_EDIFICIO));
    for (int i = 0; cartel_gameover[i] != NULL; i++) {
        mvprintw((ALTO / 2 - 5) + i, (ANCHO - 53) / 2, "%s", cartel_gameover[i]);
    }
    attroff(COLOR_PAIR(PAR_EDIFICIO));

    // Mostrar puntaje final 
    string mensajePuntaje = "PAPOTA CONSEGUIDA: " + to_string(puntaje);
    string evaluacion;
    
    if (puntaje < 30) evaluacion = "NOVATO - Necesitas mas papota!";
    else if (puntaje < 60) evaluacion = "INTERMEDIO - Vas por buen camino";
    else evaluacion = "PRO - Eres un verdadero campeon!";
    
    attron(COLOR_PAIR(PAR_JUGADOR));
    mvprintw(ALTO / 2 + 2, (ANCHO - mensajePuntaje.length()) / 2, "%s", mensajePuntaje.c_str());
    attroff(COLOR_PAIR(PAR_JUGADOR));
    
    attron(COLOR_PAIR(PAR_PREMIO));
    mvprintw(ALTO / 2 + 3, (ANCHO - evaluacion.length()) / 2, "%s", evaluacion.c_str());
    attroff(COLOR_PAIR(PAR_PREMIO));

    // Opciones
    attron(A_BOLD | COLOR_PAIR(PAR_JUGADOR));
    mvprintw(ALTO / 2 + 6, (ANCHO - 20) / 2, "R - Reiniciar juego");
    mvprintw(ALTO / 2 + 7, (ANCHO - 20) / 2, "Q - Salir del juego");
    attroff(A_BOLD | COLOR_PAIR(PAR_JUGADOR));

    refresh();

    // Esperar decisión del jugador
     char opcion;
    do {
        opcion = getch();
        opcion = a_minuscula(opcion);
    } while (opcion != 'r' && opcion != 'q');

    if (opcion == 'r') {
        return; // REINICIO
    } else {
        return; // SALIDA
    }
}
//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
char Interfaz::a_minuscula(char c) {
    if (c >= 'A' && c <= 'Z') {
        return c + 32; // Convertir a minúscula
    }
    return c;
}
