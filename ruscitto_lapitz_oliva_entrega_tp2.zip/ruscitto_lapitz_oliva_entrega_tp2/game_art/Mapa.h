//Clase Mapa
#pragma once
#include <ncurses.h>
#include <cstdlib>
#include "Constantes.h"

class Mapa {
///////////////////////////////////////////////////////////////////////////
    private: 
    char celdas[ALTO][ANCHO];
///////////////////////////////////////////////////////////////////////////
    public: 
    Mapa();
    void inicializar();
    void dibujar_mapa();
    bool puede_moverse(int y, int x) const;
    char getCelda(int y, int x) const;
    void setCelda(int y, int x, char valor);
    void colocarPremio(int &y, int &x);
    void dibujar_paso(int y, int x);
};


