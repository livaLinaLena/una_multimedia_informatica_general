#include <cstdlib>
#include <ctime>
#include <iostream>
#include <ncurses.h>
#include <vector>
#include <string>
#include "Constantes.h"
#include "Interfaz.h"
#include "Mapa.h"
#include "Jugador.h"
#include "Juego.h"

// Ruscitto, Rosalia
// Oliva, Carolina
// Lapitz, Lucas

using namespace std;

// VARIABLES GLOBALES
bool gameOver = false;
bool salirJuego = false;
int puntaje = 0;
Jugador jugador;
Mapa mapa;

// VARIABLES PARA std::string 
std::string tituloJuego = "PAPOTA: EL JUEGO";
std::string instrucciones = "Consigue toda la papota (M) para crecer mas fuerte!";
std::string controles = "Controles: Flechas/WASD para mover, Q para salir";

//FUNCIONES GLOBALES
void inicializar();
void reiniciarJuego();
void colocarPremio(int &y, int &x);
void dibujar_mapa();
bool puede_moverse(int y, int x);
void dibujar_paso(int y, int x);

///////////////////////////////////////////////////////////////////////////
int main() {
    srand(time(NULL));
    int premioX, premioY;
    Juego juego;
    initscr();
    noecho();
    keypad(stdscr, TRUE);
    curs_set(0);
    start_color();
    use_default_colors();
    Interfaz::inicializar_colores();
    bkgd(COLOR_PAIR(PAR_PASTO));
///////////////////////////////////////////////////////////////////////////    
    // Inicializar el mapa
    inicializar();

    while (!salirJuego) {
        if (juego.menu_principal()) {
            // Mostrar introducción
            Interfaz::mostrar_introduccion();
            // Inicializar juego
            reiniciarJuego();
            colocarPremio(premioY, premioX);
            int tecla = 0;

            dibujar_mapa();
            init_pair(10, COLOR_WHITE, COLOR_BLACK);
            attron(COLOR_PAIR(10));
            box(stdscr, 0, 0);
            attroff(COLOR_PAIR(10));
            Interfaz::mostrar_puntaje(puntaje);

            attron(COLOR_PAIR(PAR_JUGADOR));
            mvaddch(jugador.getY(), jugador.getX(), JUGADOR);
            attroff(COLOR_PAIR(PAR_JUGADOR));

            // Bucle principal del juego
            while (tecla != 27 && !gameOver && !salirJuego) {
                tecla = getch();

                int nuevaY = jugador.getY();
                int nuevaX = jugador.getX();

                switch (tecla) {
                case 'w':
                case 'W':
                case KEY_UP:
                    nuevaY--;
                    break;
                case 's':
                case 'S':
                case KEY_DOWN:
                    nuevaY++;
                    break;
                case 'a':
                case 'A':
                case KEY_LEFT:
                    nuevaX--;
                    break;
                case 'd':
                case 'D':
                case KEY_RIGHT:
                    nuevaX++;
                    break;
                case 'q':
                case 'Q':
                    salirJuego = true;
                    break;
                default:
                    // Otra tecla, no hacer nada
                    continue;
                }

                if (salirJuego)
                    break;

                if (!puede_moverse(nuevaY, nuevaX)) {
                    gameOver = true;
                } else {
                    // Marcar camino recorrido
                    if (mapa.getCelda(jugador.getY(), jugador.getX()) == PASTO) {
                        dibujar_paso(jugador.getY(), jugador.getX());
                    }
                    
                    jugador.mover(nuevaX, nuevaY);

                    if (mapa.getCelda(jugador.getY(), jugador.getX()) == PREMIO) {
                        jugador.sumarPuntaje(10);
                        puntaje = jugador.getPuntaje();
                        mapa.setCelda(jugador.getY(), jugador.getX(), PASTO);
                        colocarPremio(premioY, premioX);
                    }
                }

                dibujar_mapa();
                Interfaz::mostrar_puntaje(puntaje);

                attron(COLOR_PAIR(PAR_JUGADOR));
                mvaddch(jugador.getY(), jugador.getX(), JUGADOR);
                attroff(COLOR_PAIR(PAR_JUGADOR));

                move(jugador.getY(), jugador.getX());
            }

         if (gameOver) {
        Interfaz::mostrar_game_over(puntaje);
    }
        }
    }
    endwin();
    return 0;
}

void inicializar() {
    mapa.inicializar();
}

void reiniciarJuego() {
    gameOver = false;
    jugador.reiniciar();
    puntaje = 0;
    // Limpiar camino del mapa
    for (int i = 0; i < ALTO; i++) {
        for (int j = 0; j < ANCHO; j++) {
            if (mapa.getCelda(i, j) == CAMINADO) {
                mapa.setCelda(i, j, PASTO);
            }
        }
    }
}

void colocarPremio(int &y, int &x) {
    mapa.colocarPremio(y, x);
}

void dibujar_mapa() {
    mapa.dibujar_mapa();
}

bool puede_moverse(int y, int x) {
    return mapa.puede_moverse(y, x);
}

void dibujar_paso(int y, int x) {
    mapa.dibujar_paso(y, x);
}

