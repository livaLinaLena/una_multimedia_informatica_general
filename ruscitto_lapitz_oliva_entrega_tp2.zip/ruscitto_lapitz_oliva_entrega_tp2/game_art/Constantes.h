//Clase Constantes
#pragma once

const int ALTO = 40;
const int ANCHO = 120;

const char PASTO = ' ';
const char CAMINADO = '.';
const char AGUA = '~';
const char MONTANIA = '^';
const char EDIFICIO = '#';
const char PREMIO = 'M';
const char JUGADOR = '0';

enum PARES {
    PAR_PASTO = 1,
    PAR_CAMINADO,
    PAR_AGUA,
    PAR_MONTANIA,
    PAR_JUGADOR,
    PAR_EDIFICIO,
    PAR_PREMIO
};

